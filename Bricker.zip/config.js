// Firebase Configuration - GENERATED DURING BUILD
// This file is generated from config.template.js using GitHub Secrets

window.firebaseConfig = {
    apiKey: "AIzaSyCusXta6VD-G0zanUUPPMhs4Qc9aThb33Q",
    authDomain: "bricker-by-zlabs.firebaseapp.com",
    projectId: "bricker-by-zlabs",
    storageBucket: "bricker-by-zlabs.firebasestorage.app",
    messagingSenderId: "949608388167",
    appId: "1:949608388167:web:beff34c82661cf69980362"
};
